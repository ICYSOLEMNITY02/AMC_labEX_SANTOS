import React, { useState } from 'react';
import { SafeAreaView, ScrollView, View, Text, Image, TouchableOpacity, StyleSheet } from 'react-native';

const App = () => {
  const [currentSection, setCurrentSection] = useState('name');

  const resumeData = {
    imageUrl: ('https://scontent.fmnl7-1.fna.fbcdn.net/v/t39.30808-6/419852260_2160273610978770_5903021173588400387_n.jpg?_nc_cat=109&ccb=1-7&_nc_sid=efb6e6&_nc_eui2=AeGHqJS_Tr5z5XdECfs2ECaArhvJ7bWO8vWuG8nttY7y9TUzNQnPyaezXaV4bNTRBhRSv9luzi30aV2rypD764Rv&_nc_ohc=znxzFpZjBYcAX9XzHEy&_nc_ht=scontent.fmnl7-1.fna&oh=00_AfD2WTTZcAC_DfmGQHThh19lAZRzwx9pjGOH7UZM43TPww&oe=65DB6016'),
    name: 'Kyle Christopher C. Santos',
    course: 'Bachelor of Science in Information Technology',
    education: {
      elementary: 'Paltok Elementary School',
      elementaryYear: '2014',
      highSchool: 'Dalandanan National High School',
      highSchoolYear: '2018',
      college: 'Global Reciprocal Colleges',
    },
    about: 'My name is Kyle Christopher C. Santos. I am a 21-year-old resident of Valenzuela City. I always put in a lot of effort because I want to do a lot in life. In life, there is no easy money. I enjoy long bike rides with my friends, by the way.',
  projects:
    {
      projectName:'Ordering, Sales and inventory management system',
      imageSrc: 'https://scontent.fmnl7-2.fna.fbcdn.net/v/t39.30808-1/415925768_122094074660179972_5611125148054613292_n.jpg?stp=dst-jpg_p200x200&_nc_cat=102&ccb=1-7&_nc_sid=596444&_nc_eui2=AeEmS6I9gJ0tkD2dAujbFvf3RB8WzdhmNv1EHxbN2GY2_WoeTvSgN07UK4pNq6zL__9bL3psFlsZe-60cNrbGOv-&_nc_ohc=zespyft7UvAAX9UW8EK&_nc_ht=scontent.fmnl7-2.fna&oh=00_AfBUSslTgALwFOD2ldnBBiTXGKE44t1-72Jnm7L30jeCbA&oe=65DC3578',
      link: 'https://www.facebook.com/profile.php?id=61555399162340',
      description: 'An Ordering, Sales, and Inventory Management System aims to integrate and streamline various aspects of a business to enhance efficiency, accuracy, and overall performance.',
    },

    contact: {
    mobile: '09152006156',
    email: 'kylesantos02@gmail.com',
    },
  };

const handlePress = () => {
  setCurrentSection((prevSection) => {
    switch (prevSection) {
      case 'name':
        return 'education';
      case 'education':
        return 'about';
      case 'about':
        return 'projects'; // Move to the 'projects' section
      case 'projects':
        return 'contact'; // Move to the 'contact' section
      case 'contact':
        return 'name'; // Loop back to the start
      default:
        return 'name';
    }
  });
};

     return (
    <SafeAreaView style={{ flex: 1 }}>
      <ScrollView contentContainerStyle={styles.container}>
        <TouchableOpacity onPress={handlePress} style={styles.contentContainer}>
          {currentSection === 'name' && (
            <>
              <Image source={resumeData.imageUrl} style={styles.image} />
              <View style={styles.textContainer}>
                <Text style={styles.header}>{resumeData.name}</Text>
                <Text style={styles.info}>{resumeData.course}</Text>
              </View>
            </>
          )}

          {currentSection === 'education' && (
            <View style={styles.textContainer}>
              <Text style={styles.header1}>Education:</Text>
              <Text style={styles.projectTitle}>
                {'\n'}College:
                {'\n'}
                  </Text>
                <Text style={styles.info1}>{resumeData.education.college}</Text>
                {' | '}
                {resumeData.education.collegeYear}
            
              <Text style={styles.projectTitle}>
                {'\n'}High School:
                {'\n'}
                  </Text>
                <Text style={styles.info1}>{resumeData.education.highSchool}</Text>
                {' | '}
                {resumeData.education.highSchoolYear}
     
              <Text style={styles.projectTitle}>
                {'\n'}Elementary: 
                {'\n'}
                  </Text>
                <Text style={styles.info1}>{resumeData.education.elementary}</Text>
                {' | '}
                {resumeData.education.elementaryYear}
           
            </View>
          )}

          {currentSection === 'about' && (
            <View style={styles.textContainer}>
              <Text style={styles.header1}>About me:{'\n'}</Text>
              <Text style={styles.about}>{resumeData.about}</Text>
            </View>
          )}

{currentSection === 'projects' && (
  <View style={styles.projectsContainer}>
    <Text style={styles.header1}>Projects:</Text>
    <Text style={styles.projectTitle}>{resumeData.projects.projectName}</Text>
    <Image source={{ uri: resumeData.projects.imageSrc }} style={styles.projectImage} />
    <Text style={styles.projectLink}>{resumeData.projects.link}</Text>
    <Text style={styles.projectDescription}> {resumeData.projects.description}</Text>
  </View>
)}

{currentSection === 'projects1' && (
  <View style={styles.projectsContainer}>
     <Text style={styles.header1}>Projects:</Text>
    <Text style={styles.projectTitle}>{resumeData.projects1.projectName1}</Text>
    <Image source={{ uri: resumeData.projects1.imageSrc1 }} style={styles.projectImage} />
    <Text style={styles.projectLink}>{resumeData.projects1.link1}</Text>
    <Text style={styles.projectDescription}>{resumeData.projects1.description1}</Text>
  </View>
)}

          {currentSection === 'contact' && (
            <View style={styles.contactContainer}>
              <Text style={styles.header1}>Contact Me:{'\n'}</Text>
              <Text style={styles.info1}>
                {'\n'}Mobile: {resumeData.contact.mobile}
                {'\n'}Email: {resumeData.contact.email}
              </Text>
            </View>
          )}

        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  contentContainer: {
    alignItems: 'center',
    maxWidth: 600,
  },
  image: {
    width: 150,
    height: 150,
    borderRadius: 75,
    marginBottom: 20,
  },
  textContainer: {
    alignSelf: 'stretch',
  },
  header: {
    fontSize: 27,
    fontWeight: 'bold',
    marginBottom: 5,
    textAlign: 'center',
  },
  header1: {
    fontSize: 27,
    fontWeight: 'bold',
    marginBottom: 5,
    textAlign: 'left',
  },
  info: {
    fontSize: 21,
    alignSelf: 'flex-start',
    textAlign: 'center',
  },
  info1: {
    fontSize: 21,
    alignSelf: 'flex-start',
    textAlign: 'left',

  },
  about: {
    fontSize: 17,
    textAlign: 'left',
    alignSelf: 'flex-start',
  },
   projectsContainer: {
    alignSelf: 'stretch',
    marginTop: 20,
  },
  projectTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 5,
    textAlign: 'left',
  },
  projectImage: {
    width: 230,
    height: 230,
    marginBottom: 10,
    alignSelf: 'center',
  },
  projectLink: {
    fontSize: 13,
    marginBottom: 5,
    textAlign: 'center',
  },
  projectDescription: {
    fontSize: 15,
    marginBottom: 10,
    textAlign: 'justify',
  },


});

export default App;